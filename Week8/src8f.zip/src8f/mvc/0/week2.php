<?php /*

week2.php

David J. Malan
malan@harvard.edu

Represents Week 2.

*/ ?>

<!DOCTYPE html>

<html>
  <head>
    <title>Week 2</title>
  </head>
  <body>
    <h1>Week 2</h1>
    <ul>
      <li><a href="http://cdn.cs50.net/2012/fall/lectures/2/week2m.pdf">Monday</a></li>
      <li><a href="http://cdn.cs50.net/2012/fall/lectures/2/week2w.pdf">Wednesday</a></li>
    </ul>
  </body>
</html>
