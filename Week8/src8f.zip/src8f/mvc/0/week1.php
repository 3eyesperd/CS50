<?php /*

week1.php

David J. Malan
malan@harvard.edu

Represents Week 1.

*/ ?>

<!DOCTYPE html>

<html>
  <head>
    <title>Week 1</title>
  </head>
  <body>
    <h1>Week 1</h1>
    <ul>
      <li><a href="http://cdn.cs50.net/2012/fall/lectures/1/week1m.pdf">Monday</a></li>
      <li><a href="http://cdn.cs50.net/2012/fall/lectures/1/week1w.pdf">Wednesday</a></li>
    </ul>
  </body>
</html>
