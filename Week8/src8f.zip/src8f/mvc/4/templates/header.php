<!DOCTYPE html>

<html>
  <head>
    <title><?php echo htmlspecialchars($title) ?></title>
  </head>
  <body>
    <h1><?php echo htmlspecialchars($title) ?></h1>
