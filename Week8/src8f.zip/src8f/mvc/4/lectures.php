<?php require('includes/helpers.php'); ?>

<?php render('header', ['title' => 'Lectures']); ?>

<ul>
  <li><a href="week1.php">Week 1</a></li>
  <li><a href="week2.php">Week 2</a></li>
</ul>

<?php render('footer'); ?>
