<?php /*

header.php

David J. Malan
malan@harvard.edu

A header for pages.

*/ ?>

<!DOCTYPE html>

<html>
  <head>
    <title>CS50</title>
  </head>
  <body>
    <h1>CS50</h1>
