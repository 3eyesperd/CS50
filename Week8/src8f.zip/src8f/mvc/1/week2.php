<?php /*

week1.php

David J. Malan
malan@harvard.edu

Represents Week 2.

*/ ?>

<?php require('header.php'); ?>

<ul>
  <li><a href="http://cdn.cs50.net/2012/fall/lectures/2/week2m.pdf">Monday</a></li>
  <li><a href="http://cdn.cs50.net/2012/fall/lectures/2/week2w.pdf">Wednesday</a></li>
</ul>

<?php require('footer.php'); ?>
