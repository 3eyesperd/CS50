<?php /*

lectures.php

David J. Malan
malan@harvard.edu

Links to weeks.

*/ ?>

<?php require('header.php'); ?>

<ul>
  <li><a href="week1.php">Week 1</a></li>
  <li><a href="week2.php">Week 2</a></li>
</ul>

<?php require('footer.php'); ?>
