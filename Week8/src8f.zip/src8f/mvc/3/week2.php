<?php require('helpers.php'); ?>

<?php render('header', ['title' => 'Week 2']); ?>

<ul>
  <li><a href="http://cdn.cs50.net/2012/fall/lectures/2/week2m.pdf">Monday</a></li>
  <li><a href="http://cdn.cs50.net/2012/fall/lectures/2/week2w.pdf">Wednesday</a></li>
</ul>

<?php render('footer'); ?>
