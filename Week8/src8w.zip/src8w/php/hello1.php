<?php

    /****************************************************************************
     * hello1.php
     *
     * David J. Malan
     * malan@harvard.edu
     *
     * Says hello to the world.
     *
     * Demonstrates use of printf.
     ***************************************************************************/

    printf("hello, world\n");

?>
