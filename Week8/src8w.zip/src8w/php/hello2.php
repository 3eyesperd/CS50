#!/bin/php
<?php

    /****************************************************************************
     * hello2.php
     *
     * David J. Malan
     * malan@harvard.edu
     *
     * Says hello to the world.
     *
     * Demonstrates use of a shebang.
     ***************************************************************************/

    printf("hello, world\n");

?>
