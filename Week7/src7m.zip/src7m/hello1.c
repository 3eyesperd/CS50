/****************************************************************************
 * hello1.c
 *
 * David J. Malan
 * malan@harvard.edu
 *
 * Says hello to the world.
 *
 * Demonstrates use of printf.
 ***************************************************************************/

#include <stdio.h>

int main(void)
{
    printf("hello, world!\n");
    return 0;
}
